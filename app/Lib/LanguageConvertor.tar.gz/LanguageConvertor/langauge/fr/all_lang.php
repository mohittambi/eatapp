<?php return array (
  'Welcome to' => 'Bienvenue sur',
  'Your success begin with' => 'Votre succès commence par',
  'Student' => 'Student',
  'sign up via Google' => 'Inscrivez-vous par l’intermédiaire de Google',
  'sign up via facebook' => 'Inscrivez-vous via facebook',
) ?>